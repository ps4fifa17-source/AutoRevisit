import DashboardNav from "@/components/DashboardNav";
import LockedFeature from "@/components/LockedFeature";
import { getDealerContext } from "@/lib/getDealer";
import { getPlan } from "@/lib/plans";
import { redirect } from "next/navigation";
import { BarChart3, Eye, MousePointerClick, Repeat2, Trophy } from "lucide-react";

export default async function AnalyticsPage() {
  const { supabase, dealer } = await getDealerContext();

  if (!dealer) redirect("/onboarding");
  if (dealer.subscription_status !== "active") redirect("/setup-pending");

  const plan = getPlan(dealer.plan_name || "starter");
  const analyticsUnlocked = plan.analyticsEnabled;

  const { data: pages } = await supabase
    .from("customer_pages")
    .select("id, title, created_at, page_style, push_angle")
    .eq("dealership_id", dealer.id)
    .is("deleted_at", null);

  const ids = (pages || []).map((p) => p.id);

  const { data: events } = ids.length
    ? await supabase.from("page_events").select("*").in("customer_page_id", ids)
    : { data: [] };

  const views = (events || []).filter((e) => e.event_type === "view").length;
  const actions = (events || []).filter((e) => ["whatsapp_click", "call_click", "lead_submit"].includes(e.event_type)).length;
  const revisits = Math.max(0, views - (pages?.length || 0));
  const revisitRate = views ? Math.round((revisits / views) * 100) : 0;
  const topStyle = topValue((pages || []).map((p) => p.page_style || "simple"));

  return (
    <main className="min-h-screen p-4 md:p-6">
      <div className="max-w-7xl mx-auto grid md:grid-cols-[250px_1fr] gap-5">
        <DashboardNav />

        <section className="space-y-5">
          <div className="dark-card p-8 md:p-10">
            <p className="text-acid font-black mb-4">Insights</p>
            <h1 className="text-5xl md:text-7xl font-black leading-[0.9] tracking-tight">
              Understand buyer attention.
            </h1>
            <p className="text-white/60 text-lg mt-6 max-w-2xl">
              Track page views, revisit behaviour and lead actions as customer pages are opened.
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-4">
            <Metric icon={Eye} title="Page views" value={analyticsUnlocked ? views : "Pro"} />
            <Metric icon={Repeat2} title="Revisits" value={analyticsUnlocked ? revisits : "Pro"} />
            <Metric icon={MousePointerClick} title="CTA clicks" value={analyticsUnlocked ? actions : "Pro"} />
            <Metric icon={BarChart3} title="Live pages" value={pages?.length || 0} />
          </div>

          {!analyticsUnlocked && (
            <LockedFeature
              title="Advanced analytics are locked"
              description="Upgrade to Professional to track revisits, CTA clicks, page performance and customer intent."
              requiredPlan="Professional"
            />
          )}

          {analyticsUnlocked && (
            <section className="card p-7">
              <h2 className="text-3xl font-black">Performance summary</h2>
              <p className="text-ink/55 mt-2">This becomes powerful once customers open links and revisit pages.</p>

              <div className="grid md:grid-cols-3 gap-4 mt-6">
                <Insight title="Best signal" value={actions ? "CTA clicks" : views ? "Page views" : "Waiting for traffic"} />
                <Insight title="Revisit rate" value={`${revisitRate}%`} />
                <Insight title="Top style" value={topStyle || "No data yet"} />
              </div>
            </section>
          )}
        </section>
      </div>
    </main>
  );
}

function topValue(items) {
  const counts = {};
  items.filter(Boolean).forEach((item) => { counts[item] = (counts[item] || 0) + 1; });
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] || "";
}

function Metric({ icon: Icon, title, value }) {
  return (
    <div className="card p-6">
      <Icon size={22} />
      <p className="text-4xl font-black mt-5">{value}</p>
      <p className="text-ink/50 font-bold mt-1">{title}</p>
    </div>
  );
}

function Insight({ title, value }) {
  return (
    <div className="rounded-3xl bg-white/70 border border-ink/10 p-5">
      <p className="text-xs font-black text-ink/40 uppercase">{title}</p>
      <p className="text-2xl font-black mt-2">{value}</p>
    </div>
  );
}
