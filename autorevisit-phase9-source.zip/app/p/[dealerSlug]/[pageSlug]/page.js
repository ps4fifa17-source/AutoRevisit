import { createClient } from "@/lib/supabase/server";
import PageModeRenderer from "@/components/public-pages/PageModeRenderer";
import { getPlan } from "@/lib/plans";
import { fallbackSalesCopy, cleanVehicleFacts, vehicleTitleFromFacts } from "@/lib/aiPageBrain";

function customerFirst(page) {
  const raw = page?.customers?.first_name || page?.customer_name || "";
  return raw.trim().split(" ")[0] || "there";
}

function normaliseMode(value) {
  const mode = String(value || "simple").toLowerCase();
  if (mode === "first_car" || mode === "first-car") return "firstcar";
  if (mode === "running_costs" || mode === "budget") return "value";
  return mode;
}

function buildCopy(page, vehicle, mode) {
  const facts = cleanVehicleFacts(vehicle || {});
  const fallback = fallbackSalesCopy({ customerName: customerFirst(page), pushAngle: page?.push_angle || mode, vehicleFacts: facts });
  const ai = page?.ai_microcopy || page?.ai_sections || {};
  const title = vehicleTitleFromFacts(facts);
  return {
    ...fallback,
    ...ai,
    greeting: ai.greeting || page?.title || fallback.greeting,
    heroTitle: ai.heroTitle || ai.headline || page?.ai_headline || fallback.heroTitle,
    heroSubtitle: ai.heroSubtitle || ai.subline || page?.intro_message || fallback.heroSubtitle,
    whyThisVehicleTitle: ai.whyThisVehicleTitle || fallback.whyThisVehicleTitle,
    whyThisVehicleText: ai.whyThisVehicleText || fallback.whyThisVehicleText,
    topReasons: ai.topReasons || ai.quickCards || page?.ai_short_cards || fallback.topReasons,
    questions: ai.questions || fallback.questions,
    primaryCta: ai.primaryCta || page?.ai_cta || fallback.primaryCta,
    customerFirst: customerFirst(page),
    hello: ai.greeting || page?.title || fallback.greeting,
    headline: ai.heroTitle || ai.headline || fallback.heroTitle,
    intro: ai.heroSubtitle || ai.subline || fallback.heroSubtitle,
    reasons: ai.topReasons || ai.quickCards || fallback.topReasons,
    vehicleTitle: title,
  };
}

export default async function PublicCustomerPage({ params }) {
  const supabase = createClient();
  const { data: dealer } = await supabase.from("dealerships").select("*").eq("slug", params.dealerSlug).single();
  if (!dealer) return <main className="min-h-screen p-6">Dealer not found</main>;

  const { data: page } = await supabase.from("customer_pages").select("*, customers(*)").eq("slug", params.pageSlug).eq("dealership_id", dealer.id).single();
  if (!page) return <main className="min-h-screen p-6">Page not found</main>;

  const { data: pageVehicles } = await supabase.from("customer_page_vehicles").select("*, vehicles(*)").eq("customer_page_id", page.id).order("display_order", { ascending: true });
  const vehicle = pageVehicles?.[0]?.vehicles || {};
  const mode = normaliseMode(page.push_angle || page.customer_goal || page.page_style || page.page_mood || "simple");
  const plan = getPlan(dealer.plan_name || "starter");
  const showWatermark = plan.watermarkForced || page.watermark_forced || !dealer.remove_branding;

  const publicUrl = `${process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"}/p/${params.dealerSlug}/${params.pageSlug}`;
  const vehicleFacts = cleanVehicleFacts(vehicle);
  const dealerPhone = (dealer.whatsapp || dealer.phone || "").replace(/[^0-9]/g, "");
  const whatsappUrl = dealerPhone ? `https://wa.me/${dealerPhone}?text=${encodeURIComponent(`Hi, I’ve had a look at my ${vehicleTitleFromFacts(vehicleFacts)} page: ${publicUrl}`)}` : "#";

  return <PageModeRenderer mode={mode} dealer={dealer} page={page} vehicle={vehicle} copy={buildCopy(page, vehicle, mode)} whatsappUrl={whatsappUrl} showWatermark={showWatermark} />;
}
