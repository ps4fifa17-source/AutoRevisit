import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request, { params }) {
  const supabase = createClient();
  const form = await request.formData();
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) return NextResponse.redirect(new URL("/login", request.url));
  const { data: profile } = await supabase.from("profiles").select("dealership_id").eq("id", auth.user.id).single();
  if (!profile?.dealership_id) return NextResponse.redirect(new URL("/dashboard/live-pages", request.url));
  const ai_microcopy = { greeting: form.get("greeting"), subline: form.get("subline"), vehicleBadge: form.get("vehicleBadge"), quickCards: [{ title: form.get("card1Title"), text: form.get("card1Text") }, { title: form.get("card2Title"), text: form.get("card2Text") }, { title: form.get("card3Title"), text: form.get("card3Text") }, { title: form.get("card4Title"), text: form.get("card4Text") }], fitTitle: form.get("fitTitle"), fitText: form.get("fitText"), moneyTitle: form.get("moneyTitle"), moneyText: form.get("moneyText"), primaryCta: form.get("primaryCta"), secondaryCta: form.get("secondaryCta") };
  await supabase.from("customer_pages").update({ title: form.get("greeting"), intro_message: form.get("subline"), page_style: form.get("page_style"), push_angle: form.get("push_angle"), buying_for: form.get("buying_for"), page_goal: form.get("push_angle"), ai_microcopy, ai_sections: ai_microcopy, ai_short_cards: ai_microcopy.quickCards, updated_at: new Date().toISOString() }).eq("id", params.pageId).eq("dealership_id", profile.dealership_id);
  return NextResponse.redirect(new URL("/dashboard/live-pages", request.url));
}
