"use client";
import { getWhoFor, getPush, getDesignStyle } from "@/lib/pageJourney";
import { Sparkles, UserRound, Target, Palette, WalletCards } from "lucide-react";
export default function JourneyBuilderPreview({ form, selectedVehicle, dealerName }) {
  const who=getWhoFor(form.who_for), push=getPush(form.push_angle), style=getDesignStyle(form.design_style);
  return <div className="card p-7 sticky top-6">
    <div className="flex items-center gap-3"><div className="h-12 w-12 rounded-3xl bg-acid flex items-center justify-center"><Sparkles size={20}/></div><div><p className="badge mb-1">Journey brain</p><h2 className="text-3xl font-black">What AI will build around</h2></div></div>
    <div className="grid gap-3 mt-6">
      <Row icon={UserRound} label="Who it's for" value={who.label} description={who.description}/>
      <Row icon={Target} label="Push" value={push.label} description={push.description}/>
      <Row icon={Palette} label="Design style" value={style.label} description={style.description}/>
      {(form.finance_monthly||form.finance_deposit||form.finance_term||form.finance_apr)&&<Row icon={WalletCards} label="Finance" value={form.finance_monthly?`${form.finance_monthly} per month`:"Finance details added"} description={[form.finance_deposit&&`Deposit ${form.finance_deposit}`,form.finance_term&&`${form.finance_term} months`,form.finance_apr&&`${form.finance_apr}% APR`].filter(Boolean).join(" · ")}/>} 
    </div>
    <div className="rounded-[32px] bg-ink text-white p-5 mt-6 overflow-hidden"><p className="text-white/45 text-xs font-black">{dealerName||"Dealer"} will send:</p><h3 className="text-3xl font-black mt-4 leading-tight">Hello {form.customer_name||"Jack"},</h3><p className="text-white/62 mt-3">A personalised page for the {selectedVehicle||"selected vehicle"} built around {push.label.toLowerCase()}.</p></div>
  </div>;
}
function Row({icon:Icon,label,value,description}){return <div className="rounded-3xl bg-white/70 border border-ink/10 p-4 flex gap-3"><div className="h-10 w-10 rounded-2xl bg-acid/55 flex items-center justify-center shrink-0"><Icon size={18}/></div><div><p className="text-xs uppercase tracking-[0.12em] font-black text-ink/35">{label}</p><p className="font-black mt-1">{value}</p><p className="text-sm text-ink/50 mt-1">{description}</p></div></div>}
