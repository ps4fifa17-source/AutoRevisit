"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { BRAND } from "@/lib/brand";
import {
  LayoutDashboard,
  Car,
  FileStack,
  BarChart3,
  Settings,
  Sparkles,
  Plus,
  Send,
  Users,
  HeartHandshake,
  Crown,
  ShieldCheck,
} from "lucide-react";

const baseItems = [
  { href: "/dashboard", label: "Overview", icon: LayoutDashboard, exact: true, group: "Home" },
  { href: "/dashboard/vehicles", label: "Vehicles", icon: Car, group: "Stock" },
  { href: "/dashboard/vehicles/new", label: "Add vehicle", icon: Plus, group: "Stock" },
  { href: "/dashboard/pages/new", label: "Start journey", icon: Send, group: "Customer journey" },
  { href: "/dashboard/live-pages", label: "Live pages", icon: FileStack, group: "Customer journey" },
  { href: "/dashboard/leads", label: "Leads", icon: Users, group: "Customer journey" },
  { href: "/dashboard/thank-you", label: "Thank you", icon: HeartHandshake, group: "Customer journey" },
  { href: "/dashboard/analytics", label: "Analytics", icon: BarChart3, group: "Business" },
  { href: "/dashboard/settings", label: "Settings", icon: Settings, group: "Business" },
  { href: "/dashboard/upgrade", label: "Upgrade", icon: Crown, group: "Business" },
];

const adminItem = { href: "/dashboard/admin", label: "Admin", icon: ShieldCheck, group: "Admin" };

function isActive(pathname, item) {
  if (item.exact) return pathname === item.href;
  return pathname === item.href || pathname.startsWith(`${item.href}/`);
}

export default function DashboardNav() {
  const pathname = usePathname();
  const supabase = createClient();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    async function checkRole() {
      const { data: auth } = await supabase.auth.getUser();

      if (!auth.user) {
        setLoaded(true);
        return;
      }

      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", auth.user.id)
        .single();

      setIsAdmin(profile?.role === "admin");
      setLoaded(true);
    }

    checkRole();
  }, []);

  const items = isAdmin ? [...baseItems, adminItem] : baseItems;
  let lastGroup = "";

  return (
    <aside className="card p-3 md:p-4 md:sticky md:top-0 md:h-screen md:overflow-y-auto">
      <div className="hidden md:flex items-center gap-3 px-3 py-3 mb-3">
        <div className="h-11 w-11 rounded-2xl bg-ink text-acid flex items-center justify-center">
          <Sparkles size={20} />
        </div>
        <div>
          <p className="font-black leading-none">{BRAND.name}</p>
          <p className="text-xs text-ink/45 mt-1">Journey workspace</p>
        </div>
      </div>

      <div className="flex md:block gap-2 overflow-x-auto md:overflow-visible pb-2 md:pb-0">
        {items.map((item) => {
          const Icon = item.icon;
          const active = isActive(pathname, item);
          const showGroup = item.group !== lastGroup;
          lastGroup = item.group;

          return (
            <div key={item.href}>
              {showGroup && (
                <p className="hidden md:block px-4 mt-4 mb-2 text-[10px] uppercase tracking-[0.22em] font-black text-ink/35">
                  {item.group}
                </p>
              )}

              <Link
                href={item.href}
                className={`relative flex items-center gap-3 rounded-2xl transition whitespace-nowrap font-black px-4 py-3 ${
                  active ? "bg-ink text-acid shadow-lg" : "hover:bg-ink/6 text-ink"
                }`}
              >
                {active && <span className="absolute left-1 top-1/2 -translate-y-1/2 h-7 w-1 rounded-full bg-acid" />}
                <Icon size={17} />
                <span>{item.label}</span>
              </Link>
            </div>
          );
        })}
      </div>

      <div className="hidden md:block mt-5 rounded-3xl bg-ink/5 p-4">
        <p className="text-xs font-black uppercase tracking-[0.16em] text-ink/35">Current page</p>
        <p className="font-black mt-1">
          {items.find((item) => isActive(pathname, item))?.label || "Workspace"}
        </p>
        {loaded && isAdmin && <p className="text-xs font-black text-acid mt-2">Admin mode enabled</p>}
      </div>
    </aside>
  );
}
